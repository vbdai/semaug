from .InstaBoost import *
from .config import *

__all__ = ['get_new_data', 'InstaBoostConfig']
